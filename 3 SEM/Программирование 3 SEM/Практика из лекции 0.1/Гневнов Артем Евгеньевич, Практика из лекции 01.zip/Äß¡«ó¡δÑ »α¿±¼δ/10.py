x1, x2, y1, y2 = float(input()), float(input()), float(input()), float(input())
dist = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
print(dist)