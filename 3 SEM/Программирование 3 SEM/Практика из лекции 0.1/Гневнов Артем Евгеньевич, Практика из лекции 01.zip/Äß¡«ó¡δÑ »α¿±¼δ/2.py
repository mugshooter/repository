first_name = input('Имя ')
last_name = input('Фамилия ')
age = input('Возраст ')
print(f'Имя: {first_name}\nФамилия: {last_name}\nВозраст: {age}')