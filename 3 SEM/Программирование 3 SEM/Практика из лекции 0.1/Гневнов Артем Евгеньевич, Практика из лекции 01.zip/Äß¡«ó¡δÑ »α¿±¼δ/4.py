num1 = input()
num2 = int(num1 * 2)
num3 = int(num1 * 3)
print(num3 - num2 - int(num1))