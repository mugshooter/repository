a, b = float(input()), float(input())
print('Площадь S =', a * b)
print('Периметр P =', 2 * (a + b))