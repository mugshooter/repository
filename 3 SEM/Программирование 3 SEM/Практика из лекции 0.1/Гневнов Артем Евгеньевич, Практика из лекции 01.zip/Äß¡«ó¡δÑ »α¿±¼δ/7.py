time = int(input())
print(f'Поставь будильник на {time // 60}:{time % 60}')