text = input()
print(len(text))
print(text.isalpha())