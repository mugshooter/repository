text, start, end = input().lower(), input(), input()
print(text.startswith(start))
print(text.endswith(end))