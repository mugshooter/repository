text = input().lower()
print(text == text[::-1])