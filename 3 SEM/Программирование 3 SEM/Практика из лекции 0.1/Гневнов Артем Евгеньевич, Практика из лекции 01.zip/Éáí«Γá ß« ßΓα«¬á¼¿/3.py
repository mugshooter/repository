text = input()
print(text.title())