text = '12361573928167047230472012'
print(text.replace('1', 'один'))
