text = input().lower()
letter = input()
print(letter in text)