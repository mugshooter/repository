vowels = 'аиеёоуыэюя'
letter = input().lower()
print(letter in vowels)