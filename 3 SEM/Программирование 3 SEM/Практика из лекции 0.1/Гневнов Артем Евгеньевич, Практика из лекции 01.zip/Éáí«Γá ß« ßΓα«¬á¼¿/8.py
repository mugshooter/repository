text, letter = input().lower(), input()
print(text.find(letter), text.rfind(letter))